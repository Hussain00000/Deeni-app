package com.example.mydeen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.runtime.SideEffect

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Reminder.createChannel(this)
        Reminder.scheduleAll(this)
        if (Store.prefs(this).getBoolean("account_drive", false)) DriveBackup.schedule(this)
        setContent { MyDeenApp() }
    }

    override fun onStop() {
        super.onStop()
        DriveBackup.backupSoon(this)
    }
}

private val MENU = listOf(
    "home" to "Today’s checklist",
    "status" to "Daily Islamic Status",
    "tasbih" to "Digital Tasbih",
    "prayer" to "Prayer Times",
    "analysis" to "Weekly & Monthly Analysis",
    "background" to "Background",
    "reminders" to "Reminders",
    "people" to "Mulakhat People & Notes",
    "account" to "Account & Backup"
)

@Composable
fun MyDeenApp() {
    val context = LocalContext.current
    val p = Store.prefs(context)
    var loggedIn by remember { mutableStateOf(p.getBoolean("login_done", false) || Account.email(context).isNotEmpty()) }
    var epoch by remember { mutableIntStateOf(0) }
    var startScreen by remember { mutableStateOf("home") }
    var bg by remember(epoch) { mutableStateOf(loadBgState(context, Store.prefs(context))) }
    val base = remember(bg) { Bg.baseColor(context, bg) }
    MyDeenTheme(base) {
        if (!loggedIn) {
            LoginScreen { openAccount ->
                startScreen = "home"
                epoch++
                loggedIn = true
            }
        } else {
            MyDeenContent(startScreen, bg, base, onLogout = { loggedIn = false; epoch++ }) { bg = it }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MyDeenContent(startScreen: String, bg: BgState, base: Int, onLogout: () -> Unit, onBgChange: (BgState) -> Unit) {
    var screen by rememberSaveable { mutableStateOf(startScreen) }
    var menuOpen by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var profile by remember { mutableStateOf(Profile.load(context)) }
    var photoDialog by remember { mutableStateOf(false) }
    var logoutDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) Profile.save(context, uri)?.let { profile = it }
    }
    val pickPhoto = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
    val history = remember { mutableStateListOf<String>() }
    fun go(to: String) {
        if (to != screen) {
            if (screen != "home") history.add(screen)
            screen = to
        }
    }
    fun goBack() {
        screen = if (history.isNotEmpty()) history.removeAt(history.size - 1) else "home"
    }
    fun goHome() {
        history.clear()
        screen = "home"
    }
    BackHandler(enabled = screen != "home") { goBack() }
    val headerColor = MaterialTheme.colorScheme.primary
    val footerColor = MaterialTheme.colorScheme.primary
    val view = androidx.compose.ui.platform.LocalView.current
    SideEffect {
        val w = (view.context as? android.app.Activity)?.window
        if (w != null) {
            try {
                @Suppress("DEPRECATION")
                w.statusBarColor = headerColor.toArgb()
                @Suppress("DEPRECATION")
                w.navigationBarColor = footerColor.toArgb()
                val ctl = androidx.core.view.WindowCompat.getInsetsController(w, view)
                ctl.isAppearanceLightStatusBars = false
                ctl.isAppearanceLightNavigationBars = false
            } catch (e: Exception) { }
        }
    }
    val title = MENU.firstOrNull { it.first == screen }?.second ?: "My Deeni Tracker"

    if (logoutDialog) {
        val signedIn = Account.email(context).isNotEmpty()
        AlertDialog(
            onDismissRequest = { logoutDialog = false },
            title = { Text("Logout?") },
            text = { Text(if (signedIn) "Your data is saved to Google Drive first. It also stays on this phone." else "You will return to the login screen. Your data stays on this phone.") },
            confirmButton = {
                TextButton(onClick = {
                    logoutDialog = false
                    scope.launch {
                        if (signedIn && Store.prefs(context).getBoolean("account_drive", false)) {
                            withContext(Dispatchers.IO) { DriveBackup.backupNow(context) }
                        }
                        Account.signOut(context)
                        onLogout()
                    }
                }) { Text("Logout") }
            },
            dismissButton = { TextButton(onClick = { logoutDialog = false }) { Text("Cancel") } }
        )
    }

    if (photoDialog) {
        AlertDialog(
            onDismissRequest = { photoDialog = false },
            title = { Text("Profile photo") },
            text = { Text(if (profile == null) "Choose a photo from your gallery." else "Change or remove your profile photo.") },
            confirmButton = { TextButton(onClick = { photoDialog = false; pickPhoto() }) { Text(if (profile == null) "Choose photo" else "Change photo") } },
            dismissButton = {
                if (profile != null) TextButton(onClick = { Profile.remove(context); profile = null; photoDialog = false }) { Text("Remove") }
                else TextButton(onClick = { photoDialog = false }) { Text("Cancel") }
            }
        )
    }

    Box(Modifier.fillMaxSize()) {
    BackgroundLayer(bg.kind, bg.color, bg.preset, bg.custom)
    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text(if (screen == "home") "My Deeni Tracker" else title) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                navigationIcon = {
                    if (screen == "home") {
                        ProfileAvatar(profile, 36.dp, onClick = { photoDialog = true }, modifier = Modifier.padding(start = 12.dp))
                    } else {
                        IconButton(onClick = { goHome() }) {
                            Text("🏠", fontSize = 24.sp, modifier = Modifier.semantics { contentDescription = "Home" })
                        }
                    }
                },
                actions = {
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Text("⋮", fontSize = 28.sp, modifier = Modifier.semantics { contentDescription = "Menu" })
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            MENU.forEach { entry ->
                                DropdownMenuItem(
                                    text = { Text(entry.second, fontWeight = if (screen == entry.first) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = { go(entry.first); menuOpen = false }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("Logout") },
                                onClick = { menuOpen = false; logoutDialog = true }
                            )
                        }
                    }
                }
            )
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (screen) {
                "tasbih" -> TasbihScreen()
                "prayer" -> PrayerScreen()
                "analysis" -> AnalysisScreen()
                "background" -> BackgroundScreen(bg) { k, c, p, bmp -> onBgChange(BgState(k, c, p, bmp)) }
                "reminders" -> RemindersScreen()
                "account" -> AccountScreen(onLogout)
                "people" -> PeopleScreen()
                "status" -> StatusScreen()
                else -> HomeScreen(profile = profile, onProfileClick = { photoDialog = true }, onOpenAccount = { go("account") }, onOpenPeople = { go("people") })
            }
        }
    }
    }
}
