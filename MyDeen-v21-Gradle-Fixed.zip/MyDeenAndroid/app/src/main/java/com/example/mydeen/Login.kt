package com.example.mydeen

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.android.gms.auth.api.identity.Identity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** State + action for "Login with Google", shared by the first-run login screen and the Account screen. */
class GoogleLogin {
    var busy by mutableStateOf(false)
    var msg by mutableStateOf("")
    var start: () -> Unit = {}
}

/**
 * [onSignedIn] gets true when the person should look at the Account screen next
 * (Drive already has a backup and this phone has data too, or Drive could not be reached).
 */
@Composable
fun rememberGoogleLogin(onSignedIn: (Boolean) -> Unit): GoogleLogin {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val g = remember { GoogleLogin() }
    val callback by rememberUpdatedState(onSignedIn)

    fun finish(token: String) {
        scope.launch {
            val info = withContext(Dispatchers.IO) { DriveBackup.userInfo(token) }
            if (info == null || info.first.isEmpty()) {
                g.msg = "Couldn’t read your Google account. Please try again."
                g.busy = false
                return@launch
            }
            Account.signIn(context, info.first, info.second)
            var look = false
            val remote = withContext(Dispatchers.IO) { DriveBackup.remoteInfo(token) }
            if (remote == null) {
                look = true
                g.msg = "Logged in, but Google Drive could not be reached. Open Account & Backup and tap Backup now."
            } else if (remote.isEmpty()) {
                val o = withContext(Dispatchers.IO) { DriveBackup.backupNow(context) }
                if (o.ok) Account.turnOnAuto(context)
                g.msg = if (o.ok) "Logged in. Your first backup is saved." else o.message
            } else if (!Account.hasLocalData(context)) {
                val o = withContext(Dispatchers.IO) { DriveBackup.restoreNow(context) }
                if (o.ok) Account.turnOnAuto(context)
                g.msg = o.message
            } else {
                look = true
                g.msg = "A backup already exists in your Drive. Choose Restore or Backup now."
            }
            g.busy = false
            callback(look)
        }
    }

    val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        try {
            val r = Identity.getAuthorizationClient(context).getAuthorizationResultFromIntent(res.data)
            val t = r.accessToken
            if (t != null) finish(t) else { g.busy = false; g.msg = "Login cancelled." }
        } catch (e: Exception) {
            g.busy = false
            g.msg = "Login cancelled or failed."
        }
    }

    g.start = {
        g.busy = true
        g.msg = "Opening Google…"
        DriveBackup.authorize(context)
            .addOnSuccessListener { r ->
                val pi = r.pendingIntent
                if (r.hasResolution() && pi != null) {
                    consent.launch(IntentSenderRequest.Builder(pi).build())
                } else {
                    val t = r.accessToken
                    if (t != null) finish(t) else { g.busy = false; g.msg = "Login failed." }
                }
            }
            .addOnFailureListener {
                g.busy = false
                g.msg = "Google login failed (${it.message}). Check the Google Cloud setup: package name and SHA-1."
            }
    }
    return g
}

/** Shown right after installing, until the person logs in or chooses Guest. */
@Composable
fun LoginScreen(onDone: (Boolean) -> Unit) {
    val context = LocalContext.current
    val g = rememberGoogleLogin { look -> onDone(look) }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState()).padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text("My Deeni Tracker", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(
            "Login with Google to keep your data safe. It is saved automatically to your own Google Drive and comes back on a new phone.",
            style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        Button(onClick = { g.start() }, enabled = !g.busy, modifier = Modifier.fillMaxWidth()) { Text("Login with Google") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = {
                Store.prefs(context).edit().putBoolean("login_done", true).apply()
                onDone(false)
            },
            enabled = !g.busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Continue as Guest") }
        Spacer(Modifier.height(12.dp))
        Text(
            "Guest data stays only on this phone. You can login later from Menu → Account & Backup.",
            style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center
        )
        if (g.msg.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(g.msg, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        }
    }
}
